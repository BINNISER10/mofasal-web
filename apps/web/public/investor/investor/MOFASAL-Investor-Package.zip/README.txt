حزمة المستثمر — منصة مفصل (MUFASAL)
=====================================

المحتويات:
1. MOFASAL-MOU.pdf — مذكرة التفاهم بغلاف البرند (جاهزة)
2. MOFASAL-Investor-Deck.pdf — لقطات المنصة (10 شاشات)
3. README.txt — هذا الملف

التوقيع الإلكتروني: https://mofasal.netlify.app/investor/mou
